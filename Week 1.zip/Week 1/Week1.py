print('DDDD  U   U')
print('D   D U   U')
print('D   D U   U')
print('DDDD   UUU')
